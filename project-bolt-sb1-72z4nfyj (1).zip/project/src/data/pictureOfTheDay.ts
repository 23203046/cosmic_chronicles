import { format } from 'date-fns';

interface PictureOfTheDay {
  id: string;
  title: string;
  description: string;
  image: string;
  category: string;
  type: string;
  facts?: string[];
}

const astronomyPictures: Record<string, PictureOfTheDay> = {
  '01-01': {
    id: 'orion-nebula',
    title: 'The Orion Nebula - Stellar Nursery',
    description: 'The Orion Nebula is one of the brightest nebulae visible to the naked eye. Located in the constellation Orion, this stellar nursery is where new stars are born from clouds of gas and dust.',
    image: 'https://cdn.mos.cms.futurecdn.net/BRBjsRNLZTdwCUu9f9dauA.jpg',
    category: 'Nebula',
    type: 'Deep Space',
    facts: [
      'Located 1,344 light-years from Earth',
      'Contains about 2,000 times the mass of our Sun',
      'Visible to the naked eye as the middle "star" in Orion\'s sword'
    ]
  },
  '01-02': {
    id: 'saturn-rings',
    title: 'Saturn\'s Magnificent Ring System',
    description: 'Saturn\'s rings are made up of countless particles of ice and rock, ranging in size from tiny grains to house-sized chunks. This spectacular ring system spans up to 282,000 kilometers.',
    image: 'https://images.theconversation.com/files/526289/original/file-20230515-24420-u00yee.jpg?ixlib=rb-4.1.0&rect=8%2C4%2C2737%2C1337&q=45&auto=format&w=1356&h=668&fit=crop',
    category: 'Planetary',
    type: 'Solar System',
    facts: [
      'Rings are only about 10 meters thick on average',
      'Made mostly of water ice with some rocky material',
      'First observed by Galileo in 1610'
    ]
  },
  '01-03': {
    id: 'andromeda-galaxy',
    title: 'The Andromeda Galaxy - Our Cosmic Neighbor',
    description: 'The Andromeda Galaxy is the nearest major galaxy to the Milky Way and is approaching us at about 250,000 mph. In about 4.5 billion years, it will collide with our galaxy.',
    image: 'https://cdn.mos.cms.futurecdn.net/hCXYB5YKXzdq2WEHYEe36d.jpg',
    category: 'Galaxy',
    type: 'Deep Space',
    facts: [
      'Contains approximately 1 trillion stars',
      '2.537 million light-years from Earth',
      'Visible to the naked eye from dark locations'
    ]
  }
};

// Generate pictures for the entire year
const generateYearPictures = (): Record<string, PictureOfTheDay> => {
  const pictures: Record<string, PictureOfTheDay> = { ...astronomyPictures };
  
  const pictureTypes = [
    {
      title: 'Eagle Nebula - Pillars of Creation',
      description: 'The Eagle Nebula\'s famous "Pillars of Creation" are towering columns of gas and dust where new stars are forming. These cosmic sculptures stretch several light-years across.',
      category: 'Nebula',
      type: 'Deep Space',
      images: [
        'https://c.ndtvimg.com/2023-07/s6ufmmg8_eagle-nebula_625x300_30_July_23.jpg',
        'https://images.squarespace-cdn.com/content/v1/60d7296aaa6c862de19a7d3b/1627587240267-OW7ZGY7RJCIWSDO30C83/m16c-6-18-20-wm.jpg'
      ],
      facts: [
        'Located 7,000 light-years from Earth',
        'Pillars are about 4-5 light-years tall',
        'Made famous by Hubble Space Telescope images'
      ]
    },
    {
      title: 'Jupiter\'s Great Red Spot',
      description: 'Jupiter\'s Great Red Spot is a giant storm that has been raging for over 300 years. This anticyclonic storm is larger than Earth and has winds reaching 400 mph.',
      category: 'Planetary',
      type: 'Solar System',
      images: [
        'https://assets.newatlas.com/dims4/default/3656d32/2147483647/strip/true/crop/1000x667+0+118/resize/1200x800!/quality/90/?url=https%3A%2F%2Fnewatlas-brightspot.s3.amazonaws.com%2Farchive%2Fjupiter-water-1.jpg',
        'https://cdn.theatlantic.com/thumbor/x1OY-NEICIG3PAQJ4pGdTFZ5YtY=/0x227:1041x813/960x540/media/img/mt/2019/08/stsci_h_p1936a_m_1999x2000/original.png'
      ],
      facts: [
        'Could fit 2-3 Earths inside it',
        'Rotates counterclockwise every 6 days',
        'Has been shrinking over the past century'
      ]
    },
    {
      title: 'The Crab Nebula - Supernova Remnant',
      description: 'The Crab Nebula is the remnant of a supernova explosion observed by Chinese astronomers in 1054 AD. At its center lies a pulsar spinning 30 times per second.',
      category: 'Supernova Remnant',
      type: 'Deep Space',
      images: [
        'https://chandra.harvard.edu/photo/2018/crab/crab.jpg',
        'https://cdn.esawebb.org/archives/images/newsfeature/weic2417a.jpg'
      ],
      facts: [
        'Located 6,500 light-years from Earth',
        'Expanding at 1,500 kilometers per second',
        'Contains a neutron star with incredible density'
      ]
    },
    {
      title: 'Mars - The Red Planet',
      description: 'Mars gets its distinctive red color from iron oxide (rust) on its surface. This desert world has the largest volcano and canyon in the solar system.',
      category: 'Planetary',
      type: 'Solar System',
      images: [
        'https://www.edinburghnews.scotsman.com/webimg/b25lY21zOjk1MDg1YWI4LTU4ZjctNDFmYy1iOTlhLWE5ZTIyZTc3NWYxZTpjNmIzZGFmNC1hYWUzLTQ5MDgtYTljNi05NmIxNTNjZmE1MjA=.jpg?crop=3:2,smart&trim=&width=1200&auto=webp&quality=75',
        'https://i0.wp.com/lpatucson.org/central/wp-content/uploads/sites/3/2017/04/Red-Planet-header.jpg'
      ],
      facts: [
        'Has seasons similar to Earth due to axial tilt',
        'Home to Olympus Mons, the largest volcano in the solar system',
        'Evidence suggests it once had flowing water'
      ]
    },
    {
      title: 'The Horsehead Nebula',
      description: 'The Horsehead Nebula is a dark nebula silhouetted against the bright emission nebula IC 434. This iconic cosmic formation resembles the head of a horse.',
      category: 'Dark Nebula',
      type: 'Deep Space',
      images: [
        'https://www.esa.int/var/esa/storage/images/esa_multimedia/images/2023/11/euclid_s_view_of_the_horsehead_nebula/25170854-1-eng-GB/Euclid_s_view_of_the_Horsehead_Nebula_pillars.jpg',
        'https://c02.purpledshub.com/uploads/sites/48/2019/02/HH2-c9a96eb-e1607609381136.jpg'
      ],
      facts: [
        'Located about 1,500 light-years from Earth',
        'Part of the Orion Molecular Cloud Complex',
        'Will dissipate in about 5 million years'
      ]
    }
  ];

  // Fill in missing dates with procedurally generated pictures
  for (let month = 1; month <= 12; month++) {
    const daysInMonth = new Date(2024, month, 0).getDate();
    for (let day = 1; day <= daysInMonth; day++) {
      const dateKey = `${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
      
      if (!pictures[dateKey]) {
        const randomPicture = pictureTypes[Math.floor(Math.random() * pictureTypes.length)];
        pictures[dateKey] = {
          id: `picture-${dateKey}`,
          title: randomPicture.title,
          description: randomPicture.description,
          image: randomPicture.images[Math.floor(Math.random() * randomPicture.images.length)],
          category: randomPicture.category,
          type: randomPicture.type,
          facts: randomPicture.facts
        };
      }
    }
  }
  
  return pictures;
};

const allPictures = generateYearPictures();

export const getPictureOfTheDay = (date: Date): PictureOfTheDay => {
  const dateKey = format(date, 'MM-dd');
  return allPictures[dateKey] || allPictures['01-01'];
};

export const getAllPictures = () => allPictures;