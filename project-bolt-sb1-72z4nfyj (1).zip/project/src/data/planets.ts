export const planets = [
  {
    id: 'mercury',
    name: 'Mercury',
    type: 'Rocky Planet',
    color: 'bg-gradient-to-r from-gray-400 to-yellow-600',
    size: 8,
    orbitRadius: 120,
    speed: 15,
    description: "Mercury is the smallest planet in our solar system and the closest to the Sun. It has extreme temperature variations, with scorching days and freezing nights due to its lack of atmosphere.",
    facts: [
      { label: 'Distance from Sun', value: '57.9 million km' },
      { label: 'Diameter', value: '4,879 km' },
      { label: 'Day Length', value: '59 Earth days' },
      { label: 'Year Length', value: '88 Earth days' },
      { label: 'Temperature', value: '-173°C to 427°C' },
      { label: 'Moons', value: '0' }
    ],
    funFacts: [
      'Mercury is the fastest orbiting planet in our solar system',
      'A day on Mercury is longer than its year',
      'Mercury has a large iron core that makes up about 75% of its radius',
      'The planet has no atmosphere to retain heat'
    ]
  },
  {
    id: 'venus',
    name: 'Venus',
    type: 'Rocky Planet',
    color: 'bg-gradient-to-r from-yellow-400 to-orange-500',
    size: 12,
    orbitRadius: 140,
    speed: 20,
    description: "Venus is the hottest planet in our solar system due to its thick, toxic atmosphere that traps heat in a runaway greenhouse effect. It's often called Earth's twin due to similar size.",
    facts: [
      { label: 'Distance from Sun', value: '108.2 million km' },
      { label: 'Diameter', value: '12,104 km' },
      { label: 'Day Length', value: '243 Earth days' },
      { label: 'Year Length', value: '225 Earth days' },
      { label: 'Temperature', value: '462°C (surface)' },
      { label: 'Moons', value: '0' }
    ],
    funFacts: [
      'Venus rotates backwards compared to most planets',
      'It rains sulfuric acid on Venus',
      'Venus is the brightest natural object in the night sky after the Moon',
      'The atmospheric pressure on Venus is 92 times that of Earth'
    ]
  },
  {
    id: 'earth',
    name: 'Earth',
    type: 'Rocky Planet',
    color: 'bg-gradient-to-r from-blue-500 to-green-500',
    size: 14,
    orbitRadius: 160,
    speed: 25,
    description: "Earth is the only known planet to harbor life. It has liquid water, a protective atmosphere, and a magnetic field that shields us from harmful solar radiation. Our beautiful blue marble in space.",
    facts: [
      { label: 'Distance from Sun', value: '149.6 million km' },
      { label: 'Diameter', value: '12,756 km' },
      { label: 'Day Length', value: '24 hours' },
      { label: 'Year Length', value: '365.25 days' },
      { label: 'Temperature', value: '-89°C to 58°C' },
      { label: 'Moons', value: '1 (The Moon)' }
    ],
    funFacts: [
      'Earth is the only planet not named after a god',
      'The Earth\'s core is as hot as the Sun\'s surface',
      '71% of Earth\'s surface is covered by water',
      'Earth\'s magnetic field protects us from solar wind'
    ]
  },
  {
    id: 'mars',
    name: 'Mars',
    type: 'Rocky Planet',
    color: 'bg-gradient-to-r from-red-600 to-orange-600',
    size: 11,
    orbitRadius: 180,
    speed: 30,
    description: "Mars, the Red Planet, is a cold desert world with the largest volcano and canyon in the solar system. It has evidence of ancient water flows and is a prime target for finding past or present life.",
    facts: [
      { label: 'Distance from Sun', value: '227.9 million km' },
      { label: 'Diameter', value: '6,792 km' },
      { label: 'Day Length', value: '24.6 hours' },
      { label: 'Year Length', value: '687 Earth days' },
      { label: 'Temperature', value: '-87°C to -5°C' },
      { label: 'Moons', value: '2 (Phobos, Deimos)' }
    ],
    funFacts: [
      'Mars has the largest volcano in the solar system - Olympus Mons',
      'A day on Mars is very similar to Earth (24 hours 37 minutes)',
      'Mars has seasons like Earth due to its tilted axis',
      'The red color comes from iron oxide (rust) on its surface'
    ]
  },
  {
    id: 'jupiter',
    name: 'Jupiter',
    type: 'Gas Giant',
    color: 'bg-gradient-to-r from-orange-400 to-yellow-600',
    size: 28,
    orbitRadius: 220,
    speed: 40,
    description: "Jupiter is the largest planet in our solar system, a gas giant with a Great Red Spot storm larger than Earth. It acts as a cosmic vacuum cleaner, protecting inner planets from asteroids and comets.",
    facts: [
      { label: 'Distance from Sun', value: '778.5 million km' },
      { label: 'Diameter', value: '142,984 km' },
      { label: 'Day Length', value: '9.9 hours' },
      { label: 'Year Length', value: '12 Earth years' },
      { label: 'Temperature', value: '-108°C (cloud tops)' },
      { label: 'Moons', value: '95 confirmed' }
    ],
    funFacts: [
      'Jupiter has a mass greater than all other planets combined',
      'The Great Red Spot is a storm that has raged for over 300 years',
      'Jupiter has a faint ring system',
      'Jupiter\'s moon Europa may have twice as much water as Earth\'s oceans'
    ]
  },
  {
    id: 'saturn',
    name: 'Saturn',
    type: 'Gas Giant',
    color: 'bg-gradient-to-r from-yellow-300 to-orange-400',
    size: 24,
    orbitRadius: 260,
    speed: 50,
    description: "Saturn is famous for its spectacular ring system made of ice and rock particles. It's the least dense planet and would float in water if there were an ocean big enough to hold it.",
    facts: [
      { label: 'Distance from Sun', value: '1.43 billion km' },
      { label: 'Diameter', value: '120,536 km' },
      { label: 'Day Length', value: '10.7 hours' },
      { label: 'Year Length', value: '29 Earth years' },
      { label: 'Temperature', value: '-139°C (cloud tops)' },
      { label: 'Moons', value: '146 confirmed' }
    ],
    funFacts: [
      'Saturn\'s rings are made mostly of water ice',
      'Saturn is less dense than water',
      'Saturn has hexagonal clouds at its north pole',
      'Titan, Saturn\'s largest moon, has a thicker atmosphere than Earth'
    ]
  },
  {
    id: 'uranus',
    name: 'Uranus',
    type: 'Ice Giant',
    color: 'bg-gradient-to-r from-cyan-400 to-blue-500',
    size: 18,
    orbitRadius: 300,
    speed: 60,
    description: "Uranus is an ice giant that rotates on its side, making it unique among planets. It has a faint ring system and is composed mainly of water, methane, and ammonia ices around a rocky core.",
    facts: [
      { label: 'Distance from Sun', value: '2.87 billion km' },
      { label: 'Diameter', value: '51,118 km' },
      { label: 'Day Length', value: '17.2 hours' },
      { label: 'Year Length', value: '84 Earth years' },
      { label: 'Temperature', value: '-197°C (cloud tops)' },
      { label: 'Moons', value: '27 confirmed' }
    ],
    funFacts: [
      'Uranus rotates on its side at a 98-degree angle',
      'It has seasons that last 21 Earth years each',
      'Uranus was the first planet discovered with a telescope',
      'It has a faint ring system discovered in 1977'
    ]
  },
  {
    id: 'neptune',
    name: 'Neptune',
    type: 'Ice Giant',
    color: 'bg-gradient-to-r from-blue-600 to-indigo-700',
    size: 16,
    orbitRadius: 340,
    speed: 70,
    description: "Neptune is the windiest planet with speeds reaching 2,100 km/h. This ice giant has a dynamic atmosphere with changing cloud features and a Great Dark Spot similar to Jupiter's Great Red Spot.",
    facts: [
      { label: 'Distance from Sun', value: '4.50 billion km' },
      { label: 'Diameter', value: '49,528 km' },
      { label: 'Day Length', value: '16.1 hours' },
      { label: 'Year Length', value: '165 Earth years' },
      { label: 'Temperature', value: '-201°C (cloud tops)' },
      { label: 'Moons', value: '16 confirmed' }
    ],
    funFacts: [
      'Neptune has the strongest winds in the solar system',
      'It takes 165 Earth years to complete one orbit around the Sun',
      'Neptune was discovered through mathematical predictions',
      'Its largest moon, Triton, orbits backwards'
    ]
  }
];