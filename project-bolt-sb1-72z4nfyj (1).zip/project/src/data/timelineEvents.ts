export const spaceTimelineEvents = [
  {
    id: 'sputnik-1',
    title: 'Sputnik 1 Launch',
    description: 'The Soviet Union launches Sputnik 1, the first artificial satellite, marking the beginning of the Space Age.',
    year: 1957,
    category: 'satellite',
    image: 'https://media1.s-nbcnews.com/i/msnbc/Components/Slideshows/_production/ss_071004_sputnik50/ss_071004_sputnik50_11.jpg'
  },
  {
    id: 'first-human-space',
    title: 'First Human in Space',
    description: 'Yuri Gagarin becomes the first human to orbit Earth aboard Vostok 1, opening the era of human spaceflight.',
    year: 1961,
    category: 'mission',
    image: 'https://healthimaging.com/sites/default/files/styles/top_stories/public/assets/articles/astronaut_space.jpeg.webp?itok=6EqswHYa'
  },
  {
    id: 'apollo-11',
    title: 'Apollo 11 Moon Landing',
    description: 'Neil Armstrong and Buzz Aldrin become the first humans to walk on the Moon while Michael Collins orbits above.',
    year: 1969,
    category: 'mission',
    image: 'https://techstartups.com/staging/wp-content/uploads/2021/11/landing-960x581.jpg'
  },
  {
    id: 'voyager-launch',
    title: 'Voyager Missions Launch',
    description: 'NASA launches Voyager 1 and 2 to explore the outer solar system, providing unprecedented views of gas giants.',
    year: 1977,
    category: 'launch',
    image: 'https://cdnph.upi.com/sv/ph/og/i/3361660872230/2022/1/16609131884847/v1.5/45-years-after-launch-NASAs-Voyager-probes-still-blazing-trails-billions-of-miles-away.jpg'
  },
  {
    id: 'hubble-launch',
    title: 'Hubble Space Telescope Launch',
    description: 'The Hubble Space Telescope is deployed, revolutionizing our understanding of the universe with stunning images.',
    year: 1990,
    category: 'satellite',
    image: 'https://science.nasa.gov/wp-content/uploads/2023/04/hubble-astronaut-missions-atlantislaunch-jpg.webp'
  },
  {
    id: 'iss-construction',
    title: 'International Space Station',
    description: 'Construction begins on the International Space Station, creating a permanent human presence in space.',
    year: 1998,
    category: 'mission',
    image: 'https://www.nasa.gov/wp-content/uploads/2023/05/iss065e373746.jpg?w=1536'
  },
  {
    id: 'mars-rovers',
    title: 'Mars Exploration Rovers',
    description: 'Spirit and Opportunity rovers land on Mars, beginning extensive geological surveys of the Red Planet.',
    year: 2004,
    category: 'mission',
    image: 'https://www.sciencelearn.org.nz/_next/image?url=https%3A%2F%2Fwww.datocms-assets.com%2F117510%2F1722389708-slh_news34_curiosity_rover_original.jpg%3Fw%3D1840%26h%3D1034.816&w=1920&q=85&dpl=dpl_79jZSFM8Lm7mxFkCz5tGN2qR3WmU'
  },
  {
    id: 'spacex-falcon-heavy',
    title: 'Falcon Heavy First Flight',
    description: 'SpaceX successfully launches the Falcon Heavy, demonstrating the future of reusable heavy-lift rockets.',
    year: 2018,
    category: 'launch',
    image: 'https://nss.org/wp-content/uploads/2019/01/falcon-heavy.jpg'
  },
  {
    id: 'james-webb',
    title: 'James Webb Space Telescope',
    description: 'NASA launches the James Webb Space Telescope, the most powerful space telescope ever built.',
    year: 2021,
    category: 'satellite',
    image: 'https://images.theconversation.com/files/672021/original/file-20250603-68-pimc7g.jpg?ixlib=rb-4.1.0&q=45&auto=format&w=1000&fit=clip'
  },
  {
    id: 'artemis-1',
    title: 'Artemis 1 Mission',
    description: 'NASA launches Artemis 1, an uncrewed test flight around the Moon as part of the return to lunar exploration.',
    year: 2022,
    category: 'mission',
    image: 'https://images.foxweather.com/static.foxweather.com/www.foxweather.com/content/uploads/2022/08/1024/512/Screen-Shot-2022-08-05-at-11.38.40-AM.png?ve=1&tl=1'
  }
];